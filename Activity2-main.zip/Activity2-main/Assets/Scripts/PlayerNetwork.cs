using UnityEngine;
using Unity.Netcode;
using UnityEngine.UI;

public class PlayerNetwork : NetworkBehaviour
{
    [Header("Movement")]
    public float moveSpeed = 5f;

    [Header("Health")]
    public int maxHealth = 100;

    [Header("References")]
    public Slider healthBarUI;

    [Header("Shooting")]
    public GameObject bulletPrefab;
    public Transform firePoint;
    public float fireRate = 0.25f;
    private float nextFireTime = 0f;

    public NetworkVariable<int> health = new NetworkVariable<int>(100,
        NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

    public NetworkVariable<int> score = new NetworkVariable<int>(0,
        NetworkVariableReadPermission.Everyone, NetworkVariableWritePermission.Server);

    private bool isDead = false;

    public override void OnNetworkSpawn()
    {
        if (IsServer)
        {
            health.Value = maxHealth;
        }

        health.OnValueChanged += (oldVal, newVal) =>
        {
            if (healthBarUI != null) healthBarUI.value = (float)newVal / maxHealth;
            if (newVal <= 0 && !isDead) Die();
        };

        if (healthBarUI != null) healthBarUI.value = (float)health.Value / maxHealth;
    }

    void Update()
    {
        if (!IsOwner || isDead) return;

        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        Vector3 move = new Vector3(h, 0, v);

        bool moving = move.magnitude > 0.1f;

        if (moving)
        {
            transform.position += move.normalized * moveSpeed * Time.deltaTime;
            transform.forward = move.normalized;
        }

        if (Input.GetMouseButtonDown(0) && Time.time >= nextFireTime)
        {
            nextFireTime = Time.time + fireRate;
            ShootServerRpc();
        }
    }

    [ServerRpc(RequireOwnership = false)]
    public void TakeDamageServerRpc(int damage, ulong shooterClientId)
    {
        if (isDead) return;

        health.Value -= damage;
        if (health.Value < 0) health.Value = 0;

        if (health.Value == 0)
        {
            AwardScoreToShooter(shooterClientId);
        }
    }

    void AwardScoreToShooter(ulong shooterClientId)
    {
        if (!NetworkManager.Singleton.ConnectedClients.TryGetValue(shooterClientId, out var client))
            return;
        if (client.PlayerObject == null) return;

        var shooterPlayer = client.PlayerObject.GetComponent<PlayerNetwork>();
        if (shooterPlayer != null) shooterPlayer.score.Value += 10;
    }

    void Die()
    {
        isDead = true;
    }

    [ServerRpc]
    void ShootServerRpc()
    {
        if (isDead || bulletPrefab == null || firePoint == null) return;

        GameObject bulletObj = Instantiate(bulletPrefab, firePoint.position, transform.rotation);
        var bullet = bulletObj.GetComponent<Bullet>();
        if (bullet != null) bullet.Init(OwnerClientId);
        bulletObj.GetComponent<NetworkObject>().Spawn();
    }
}