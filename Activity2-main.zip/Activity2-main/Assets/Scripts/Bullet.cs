using UnityEngine;
using Unity.Netcode;

public class Bullet : NetworkBehaviour
{
    public float speed = 15f;
    public int damage = 25;
    public float lifeTime = 3f;

    private ulong ownerClientId;
    private bool hasHit = false;

    public void Init(ulong shooterId)
    {
        ownerClientId = shooterId;
    }

    public override void OnNetworkSpawn()
    {
        if (IsServer)
        {
            Invoke(nameof(DespawnBullet), lifeTime);
        }
    }

    void DespawnBullet()
    {
        if (NetworkObject != null && NetworkObject.IsSpawned)
        {
            NetworkObject.Despawn();
        }
    }

    void Update()
    {
        transform.position += transform.forward * speed * Time.deltaTime;
    }

    void OnTriggerEnter(Collider other)
    {
        if (!IsServer || hasHit) return;

        var hitPlayer = other.GetComponent<PlayerNetwork>();
        if (hitPlayer == null) return;

        var netObj = other.GetComponent<NetworkObject>();
        if (netObj == null) return;

        if (netObj.OwnerClientId == ownerClientId) return;

        hasHit = true;
        hitPlayer.TakeDamageServerRpc(damage, ownerClientId);

        CancelInvoke(nameof(DespawnBullet));
        DespawnBullet();
    }
}