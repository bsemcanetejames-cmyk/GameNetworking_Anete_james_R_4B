using UnityEngine;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;

public class NetworkUI : MonoBehaviour
{
    private string ipAddress = "127.0.0.1";

    private GUIStyle labelStyle;
    private GUIStyle fieldStyle;
    private GUIStyle buttonStyle;
    private bool stylesReady = false;

    void BuildStyles()
    {
        labelStyle = new GUIStyle(GUI.skin.label);
        labelStyle.fontSize = 14;
        labelStyle.fontStyle = FontStyle.Italic;

        fieldStyle = new GUIStyle(GUI.skin.textField);
        fieldStyle.fontSize = 14;
        fieldStyle.fontStyle = FontStyle.Italic;

        buttonStyle = new GUIStyle(GUI.skin.button);
        buttonStyle.fontSize = 18;
        buttonStyle.fontStyle = FontStyle.BoldAndItalic;

        stylesReady = true;
    }

    void OnGUI()
    {
        if (NetworkManager.Singleton == null) return;
        if (!stylesReady) BuildStyles();

        if (!NetworkManager.Singleton.IsClient && !NetworkManager.Singleton.IsServer)
        {
            GUI.Label(new Rect(20, 20, 100, 20), "IP Address:", labelStyle);
            ipAddress = GUI.TextField(new Rect(110, 20, 110, 20), ipAddress, fieldStyle);

            if (GUI.Button(new Rect(20, 55, 200, 40), "Start Host", buttonStyle))
                NetworkManager.Singleton.StartHost();

            if (GUI.Button(new Rect(20, 105, 200, 40), "Start Client", buttonStyle))
            {
                var transport = NetworkManager.Singleton.GetComponent<UnityTransport>();
                if (transport != null)
                {
                    transport.ConnectionData.Address = ipAddress;
                }
                NetworkManager.Singleton.StartClient();
            }
        }
        else
        {
            GUI.Label(new Rect(20, 20, 300, 30),
                $"Mode: {(NetworkManager.Singleton.IsHost ? "Host" : "Client")}", labelStyle);
        }
    }
}